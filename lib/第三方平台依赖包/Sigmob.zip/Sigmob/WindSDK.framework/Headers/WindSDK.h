//
//  WindSDK.h
//  WindSDK
//
//  Created by happyelements on 2018/4/8.
//  Copyright © 2018 Codi. All rights reserved.
//

#import <UIKit/UIKit.h>

// Header files.
#import <WindSDK/WindAds.h>
#import <WindSDK/WindAdOptions.h>
#import <WindSDK/WindRewardedVideoAd.h>
#import <WindSDK/WindRewardVideoAdAdapter.h>
#import <WindSDK/WindRewardVideoAdConnector.h>
#import <WindSDK/WindProtocol.h>
#import <WindSDK/WindRewardInfo.h>
#import <WindSDK/WindAdRequest.h>
#import <WindSDK/WADStrategy.h>
#import <WindSDK/WindSplashAd.h>
#import <WindSDK/WindSplashAdAdapter.h>
#import <WindSDK/WindSplashAdConnector.h>
#import <WindSDK/WindFullscreenVideoAd.h>
#import <WindSDK/SIGLog.h>




